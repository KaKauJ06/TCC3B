<?php

    include_once ('conexao.php');

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recebendo os dados do formulário
    $nome = $_POST['nome'];
    $matricula = $_POST['m_a'];
    $idade = intval($_POST['idade']); // Converte para um número inteiro
    if ($idade <= 0 || $idade > 70) {
        die("Por favor, insira uma idade válida (entre 1 e 70).");
    }
    $senhausuario = $_POST['senha']; $senhacript = password_hash($senhausuario, PASSWORD_DEFAULT); // Hash da senha para segurança
    $genero = $_POST['genero'];
    $turma = $_POST['Turma:'];
    $modalidadeindi = $_POST['MODALIDADESIND'];
    $modalidadeequipe = $_POST['MODALIDADESCOLE'];
    $altura= 1;
    $peso= 1;

    // Inserindo os dados no banco de dados
   $sql = "INSERT INTO tela_cadastro(NOME,Matricula_Aluno,Idade,Senha,Genero,Turma,Modalidadeindividual,Modalidadeequipe,Altura,Peso) VALUES ('$nome', '$matricula', '$idade', '$senhacript','$genero','$turma','$modalidadeindi','$modalidadeequipe','$altura','$peso')";

    if ($conexao->query($sql) === TRUE) {
        echo '<script>alert("Cadastrado com sucesso!"); window.location.href = "TELALOGIN.html"</script>';  
    } else {
        echo "Erro ao cadastrar: " . $conexao->error;
    }
} 

?>