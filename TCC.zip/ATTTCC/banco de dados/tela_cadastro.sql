-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 09-Ago-2023 às 01:16
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cadastro1`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tela_cadastro`
--

CREATE TABLE `tela_cadastro` (
  `ID` int(11) NOT NULL,
  `NOME` varchar(250) NOT NULL,
  `Matricula_aluno` varchar(12) NOT NULL,
  `Idade` int(2) NOT NULL,
  `Senha` varchar(25) NOT NULL,
  `GENERO` enum('Masculino','Feminino') NOT NULL,
  `TURMA` enum('6A','6B','7A','7B','8A','8B','9A','9B') NOT NULL,
  `MODALIDADE` enum('ATLETISMO','BADMINTON','BASQUETEBOL','FUTEBOL_DE_CAMPO','FUTSAL','HANDEBOL','JUI_JITSU','TAEKWOND','VOLEI_DE_QUADRA','VOLEI_DE_PRAIA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tela_cadastro`
--
ALTER TABLE `tela_cadastro`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tela_cadastro`
--
ALTER TABLE `tela_cadastro`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
