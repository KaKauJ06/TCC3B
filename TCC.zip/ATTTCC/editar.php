<?php
$ID = $_GET['aluno1'];
    include_once 'conexao.php';
    $res = mysqli_query($conexao,"SELECT NOME,Idade,Genero,Turma,Modalidadeindividual,Modalidadeequipe,Altura,Peso FROM tela_cadastro WHERE ID = $ID");
    $dados = mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alterar Cadastro</title>
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.css">
    <style> 

         body {
            background-image:url(https://i.pinimg.com/1200x/02/8a/02/028a028c78a344a06853e628f9fa994d.jpg);
       background-repeat: no-repeat;
background-size: cover;
background-attachment: fixed; }

h2{
    text-align: center;
    margin-bottom: 20px;
}

.card{
    margin:auto;
    justify-content:center;
    width: 30em;
    margin-top: 100px;
    background-color: #fff;
    padding: 60px;
    border-radius: 7%;
    box-shadow: 10px 10px 5px 5px #00000080;
}
</style>
</head>












<body>
<div class="card">
        <h2 class="mb-2">Editar Cadastro</h2><br>

            <form method="POST" autocomplete="off">

            <body>
        <div class="card">
        <form action="processar_cadas.php" method="POST" autocomplete="off">
                <div class="row">
                     <h1 class="mb-2">Editar</h1><br>
            <div class="col-md-14 mb-3">
            <label for="nome">Nome</label>
          <input type="text" name="novo_nome" class="form-control" placeholder="Digite seu Nome Completo" required>
           </div>


            <div class="col-md-14 mb-3">
        <label for="idade">Idade</label>
        <input type="text" name="nova_idade" class="form-control" placeholder="Digite sua Idade "  required maxlength="2">
           </div>
>
            <div class="col-md-14 mb-3">
                    <label>Gênero</label>
                    <select name="novo_genero" class="form-control" required>
                        <option value="" disabled selected>Escolha o Sexo</option>
                        <option value="Masculino"  <?php if ($dados[2] == 'Masculino') echo 'selected'; ?>>Masculino</option>
                        <option value="Feminino"  <?php if ($dados[2]== 'Feminino') echo 'selected'; ?> >Feminino</option>
                    </select>
                    <br>
                </div>

            <div class="col-md-14 mb-3">
        <label for="Turma:">Turma</label><br>
        <select class="form-control" id="Turma:" name="nova_turma" required>
            <option value="" disabled selected>Escolha a Sua Turma</option>
            <option value="6B">6°A</option>
            <option value="6B">6°B</option>
            <option value="7A">7°A</option>
            <option value="7B">7°B</option>
            <option value="8A">8°A</option>
            <option value="8B">8°B</option>
            <option value="9A">9°A</option>
            <option value="9B">9°B</option>
        </select>
            </div>

     <div class="col-md-14 mb-3">
        <label for="MODALIDADES">MODALIDADES INDIVIDUAIS</label><br>
     <select class="form-control" id="MODALIDADESIND" name="nova_modal" required>
        <option value="" disabled selected> Escolha a Sua Modalidade Individual</option>
        <option value="NENHUMA">NENHUMA</option>
        <option value="ATLETISMO">ATLETISMO</option>
        <option value="BADMINTON">BADMINTON</option>
        <option value="JUI_JITSU">JUI-JITSU</option>
        <option value="TAEKWOND">TAEKWOND</option>
     </select>
 </div>

             <div class="col-md-14 mb-3">
     <label for="MODALIDADES">MODALIDADES EM EQUIPE</label><br>
     <select class="form-control" id="MODALIDADESCOLE" name="nova_equip" required>
        <option value="" disabled selected> Escolha a Sua Modalidade em Equipe</option>
        <option value="NENHUMA">NENHUMA</option>
        <option value="BASQUETEBOL">BASQUETEBOL</option>
        <option value="FUTEBOL_DE_CAMPO">FUTEBOL DE CAMPO</option>
        <option value="FUTSAL">FUTSAL</option>
        <option value="HANDEBOL">HANDEBOL</option>
        <option value="VOLEI_DE_QUADRA">VOLEI DE QUADRA</option>
        <option value="VOLEI_DE_PRAIA">VOLEI DE PRAIA</option>
     </select>       
</div>
           <div class="col-md-14 mb-3">
            <label for="altura">Altura</label>
          <input type="text" name="nova_altura" class="form-control" placeholder="Altura em Centímetros" required>
           </div>

           <div class="col-md-14 mb-3">
            <label for="nome">Peso</label>
          <input type="text" name="novo_peso" class="form-control" placeholder="Peso em Quilos" required>
           </div>
           <input type="submit" name="alterar" value="ALTERAR" class="btn btn-dark"/>
</div>
</div>
</div>
</div>
 </div>

         </form>
</body>
</html>
<?php
if (isset($_POST['alterar'])) 
            { 
                $novo_nome =   $_POST["novo_nome"];
                $nova_idade =  $_POST["nova_idade"];
                $novo_genero =  $_POST["novo_genero"];
                $nova_turma =  $_POST["nova_turma"];
                $nova_modal =  $_POST["nova_modal"];
                $nova_equip =  $_POST["nova_equip"];
                $nova_altura = $_POST["nova_altura"];
                $novo_peso =   $_POST["novo_peso"];


    include_once ('conexao.php');


    $att = "UPDATE tela_cadastro SET NOME = '$novo_nome', Idade ='$nova_idade' , Genero = '$novo_genero', Turma = '$nova_turma', Modalidadeindividual = '$nova_modal', Modalidadeequipe = '$nova_equip', Altura = '$nova_altura', Peso = '$novo_peso' WHERE ID = $ID";

    $rest = mysqli_query($conexao,$att);

    switch ($rest) {
        case '$rest == true':
            echo '<script>alert("Cadastro atualizado com sucesso!")';  
            break;

        default:
            echo 'Não foi possível atualizar o cadastro! :(';
}
}
?>