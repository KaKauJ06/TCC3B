<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Título da página</title>
    <link rel="stylesheet" type="Text/css" href="tela_inicial.css">
    
</head>

<body>
	<div id="sidebar">
		<div id="logo">
        <img src="../TCC/img/logo.jpeg" alt="logo">
         <h1>Atleta Frequente</h1>
    </div>
    <ul>
        <li><a href="telainicial.php">Página Inicial</a></li>
        <li><a href="presenca.php">Formulário de Presença</a></li>
        <li><a href="perfil.php">Perfil</a></li>
        <li><a href="#">_____</a></li>
    </ul>
</div>
</body>
</html>
