<?php
    $IDparaaula = $_GET['CODIGO2'];
    include_once('conexao.php');

    $aula = "SELECT ID,Aula,Dia, Horario, Observacoes FROM treinos WHERE ID = '$IDparaaula'";
    $executar = mysqli_query($conexao, $aula);

    $linha = mysqli_fetch_array($executar);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Título da página</title>
    <link rel="stylesheet" type="text/css" href="tela_inicial.css">
</head>

<body>
    <div id="sidebar">
        <div id="logo">
            <img src="../TCC/img/logo.jpeg" alt="logo">
            <h1>Atleta Frequente</h1>
        </div>
        <ul>
            <li><a href="telainicial.php">Página Inicial</a></li>
            <li><a href="presenca.php">Formulário de Presença</a></li>
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="#">_____</a></li>
        </ul>
    </div>

    <p>
        INFORMAÇÕES<br>
        Treino: <?php echo $linha[1]; ?> <br>
        Data: <?php $data = date('d/m/Y',    strtotime($linha[2])); echo $data; ?> <br>
        Horário: <?php $hora = date('H:i', strtotime($linha[3])); echo $hora; ?> <br>
        Observações: <?php echo $linha[4]; ?> <br>
    </p><br>
         <a href='chamada.php?chamada=<?php echo $IDparaaula;?>'>Editar chamadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</a>
    <table>
        <thead>
            <tr>
                <th>Nome do Aluno</th>
                <th>Presença</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include_once('conexao.php');

            $consulta_alunos = "SELECT ID, NOME FROM tela_cadastro";
            $resultado_alunos = mysqli_query($conexao, $consulta_alunos);

            if ($resultado_alunos) {
                while ($row = mysqli_fetch_array($resultado_alunos)) {
                    $aluno_id = $row['ID'];
                    $nome_aluno = $row['NOME'];

                    $consulta_presenca = "SELECT Presenca FROM chamada WHERE aula_id = '$IDparaaula' AND aluno_id = '$aluno_id'";
                    $resultado_presenca = mysqli_query($conexao, $consulta_presenca);

                    if ($resultado_presenca && $presenca_row = mysqli_fetch_array($resultado_presenca)) {
                        $presente = $presenca_row['Presenca'];

                        $status_presenca = $presente ? 'Presente' : 'Ausente';

                        echo "<tr>";
                        echo "<td>" . $nome_aluno . "</td>";
                        echo "<td>" . $status_presenca . "</td>";
                        echo "</tr>";
                    }
                }
            } else {
                echo "Erro na consulta: " . mysqli_error($conexao);
            }
            ?>
        </tbody>
    </table>
</body>
</html>