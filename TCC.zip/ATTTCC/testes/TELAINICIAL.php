<!DOCTYPE html>
<html>
<head> Lembra de incluir o php pra fazer a pesquisa com o include once
    <title></title>
</head>
<body>
    <form action= "pesquisa.php" method="get">
        <label for="nome">Pesquisar</label>
        <input type="text" id="nome" name="nomedoalunopesquisar">
        <input type="submit" value="Pesquisar"> <br> <br>
    </form>

        <table class="table table-striped">
            <thead class="table-dark">
                <td>FOTO</td>
                <td>NOME</td>
            </thead>
            <tbody>
        <?php
        include_once 'conexao.php';
        $dados = "SELECT NOME, FOTO FROM NOME DA TABELA";
        $resposta = mysqli_query($conexao,$dados);
        while ($linha = mysqli_fetch_array($resposta)){
            echo "<tr>
                    <td>$linha[FOTO]</td>
                    <td>$linha[NOME]</td>
            </tr>";
        }
        echo "</tbody>
            </table>"
    ?>
</body>
</html>