<?php
// COLOCA O ARQUIVO DE CONEXAO
$nome = $_GET['nomedoalunopesquisar'];

$pesquisa = "SELECT * FROM tabela_pessoas WHERE nome LIKE '%$nome%'";

$resultado = mysqli_query($conexao, $pesquisa);

echo "<h2>Resultados da Pesquisa:</h2>";
while ($pesquisarrr = mysqli_fetch_assoc($resultado)) {
    echo "Nome: " . $row['nome'] .  "<br>";
}

?>