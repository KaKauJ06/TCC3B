<?php
include_once('conexao.php');

$aluno_id = $_GET['aluno'];

// Consulta para obter as aulas e a presença do aluno
$sql = "SELECT t.Aula, t.Dia, t.Horario, c.Presenca
        FROM treinos t
        LEFT JOIN chamada c ON t.ID = c.aula_id AND c.aluno_id = $aluno_id";

$result = $conexao->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Presença nas Aulas</title>
</head>
<body>
    <h1>Presença nas Aulas</h1>

    <?php
    if ($result->num_rows > 0) {
        echo "<table><tr><th>Aula</th><th>Dia</th><th>Horário</th><th>Presença</th></tr>";
        while ($row = $result->fetch_assoc()) {
            $presenca = $row['Presenca'] ? 'Presente' : 'Ausente';
            echo "<tr><td>" . $row['Aula'] . "</td><td>" . $row['Dia'] . "</td><td>" . $row['Horario'] . "</td><td>" . $presenca . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "Nenhum registro encontrado.";
    }

    $conexao->close();
    ?>

    <br>
</body>
</html>