
<?
  include_once('conexao.php');

// Captura dos dados do formulário
if (isset($_POST['matricula']) && isset($_POST['senha'])) {
    $matricula = $_POST['matricula'];
    $senha = $_POST['senha'];

    // Consulta SQL para verificar o login
  $sql_code = "SELECT * FROM tela_cadastro WHERE Matricula_aluno = '$matricula' LIMIT 1";
    $sql_exec = $conexao->query($sql_code) or die($mysqli->error);

    $user= $sql_exec->fetch_assoc();
    if(password_verify($senha, $user['Senha'])){
         echo '<script>alert("Login realizado com sucesso!"); window.location.href = "telainicial.php"</script>';
    }else{
         echo "Falha no login";
    }}

?>




















