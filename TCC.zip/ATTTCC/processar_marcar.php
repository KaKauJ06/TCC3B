<?php

include_once ('conexao.php');
$titulo = $_POST['titulo'];
$dia = $_POST['dia'];
$horario = $_POST['horario'];
$observacoes = $_POST['observacoes'];

$sql = "INSERT INTO treinos (Aula, Dia, Horario, Observacoes) VALUES ('$titulo', '$dia', '$horario', '$observacoes')";

if (mysqli_query($conexao, $sql)) {
    echo "Dados inseridos com sucesso!";
} else {
    echo "Erro ao inserir dados: " . mysqli_error($conn);
}
?>