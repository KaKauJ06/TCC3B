<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>INICIO</title>
	<link rel="stylesheet" type="Text/css" href="tela_inicial.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div id="sidebar">
		<div id="logo">
        <img src="../TCC/img/logo.jpeg" alt="logo">
         <h1>Atleta Frequente</h1>
    </div>
    <ul>
        <li><a href="telainicial.php">Página Inicial</a></li>
        <li><a href="presenca.php">Formulário de Presença</a></li>
        <li><a href="perfil.php">Perfil</a></li>
        <li><a href="#">_____</a></li>
    </ul>
</div>

	<div class="container">
		<h2 class="mb-6"> </h2>
		<table class="table table-hover table-borderless">
			<thead class="thead-light">
			<tr>
			<th>Matrícula</th>
			<th>Nome</th>
			<th>Turma</th>
			<th>Presença</th>
			<th>Excluir</th>
			<th>Perfil</th>
		</thead>
		<tbody>
<?php
	include_once 'conexao.php';

			$dados = "SELECT Matricula_aluno,NOME,Turma FROM tela_cadastro";

			$resposta = mysqli_query($conexao,$dados);

			while ($linha = mysqli_fetch_array($resposta)){
				echo "<tr>
				<td>$linha[Matricula_aluno]</td>
				<td>$linha[NOME]</td>
				<td>$linha[Turma]</td>
                <td><checkbox>Presença</checkbox></td>
				<td>
				<a href='excluir.php?CODIGO=$linha[Matricula_aluno]'>
					<img id='lixo' src='https://static.vecteezy.com/system/resources/thumbnails/009/344/493/small/x-transparent-free-png.png' alt='Excluir'/>
					</a>
				</td>
				<td>
				<a href='perfill.php?CODIGO1=$linha[Matricula_aluno]'> Perfil </a>
				</td>
				 
		</tr>";
	}
	
?>
	
</tbody>
</table>
</div>
</body>
</html>