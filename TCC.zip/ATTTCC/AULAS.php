<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tabela de Aulas</title>
</head>
<body>
    <h2>Tabela de Aulas</h2>

    <table>
        <thead>
            <tr>
                <th>Título</th>
                <th>Data</th>
                <th>Horário</th>
                <th>Opções</th>
            </tr>
        </thead>
        <tbody>


            <?php
	          include_once 'conexao.php';

			$dados = "SELECT ID,Aula,Dia, Horario FROM treinos";

			$resposta = mysqli_query($conexao,$dados);

			while ($linha = mysqli_fetch_array($resposta)){
				echo "<tr>
				<td>$linha[Aula]</td>
				<td>$linha[Dia]</td>
				<td>$linha[Horario]</td>
				<td>
				<a href='aula.php?CODIGO2=$linha[ID]'> Ver mais </a>
				</td>
				 
		</tr>";
	}
	
?>

        </tbody>
    </table>
</body>
</html>