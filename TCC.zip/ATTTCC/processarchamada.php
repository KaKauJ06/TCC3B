<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifique se o ID da aula foi enviado.
    if (isset($_POST["id_aula"])) {
        include_once ('conexao.php');

        // ID da aula e lista de IDs dos alunos (presença).
        $id_aula = $_POST["id_aula"];
        $presenca_alunos = $_POST["presenca"];

        // Remova todos os registros de presença para esta aula.
        $sql_delete = "DELETE FROM chamada WHERE aula_id = '$id_aula'";
        if (mysqli_query($conexao, $sql_delete)) {
            // Insira os novos registros de presença.
            foreach ($presenca_alunos as $aluno_id) {
                $sql_insert = "INSERT INTO chamada (aula_id, aluno_id, Presenca) VALUES ('$id_aula', '$aluno_id', 1)";
                mysqli_query($conexao, $sql_insert);
            }
              echo "<a href= aula.php?CODIGO2=$id_aula;> Voltar para a Aula </a>";
        } else {
            echo "Erro ao registrar presença: " . mysqli_error($conexao);
        }

        // Feche a conexão com o banco de dados.
        mysqli_close($conexao);
    } else {
        echo "ID da aula não fornecido.";
    }
} else {
    echo "Acesso inválido.";
}
?>