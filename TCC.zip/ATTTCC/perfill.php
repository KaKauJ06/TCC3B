<?php
	$Matriculaparaperfil = $_GET['CODIGO1'];
	include_once ('conexao.php');
	
$perfil= "SELECT ID, NOME, Matricula_aluno, Idade, Genero, Turma, Modalidadeindividual, Modalidadeequipe, Altura, Peso FROM tela_cadastro WHERE Matricula_aluno = '$Matriculaparaperfil'";
$executar= mysqli_query($conexao,$perfil);

$linha = mysqli_fetch_array($executar);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Título da página</title>
    <link rel="stylesheet" type="Text/css" href="tela_inicial.css">
    
</head>

<body>
	<div id="sidebar">
		<div id="logo">
        <img src="../TCC/img/logo.jpeg" alt="logo">
         <h1>Atleta Frequente</h1>
    </div>
    <ul>
        <li><a href="telainicial.php">Página Inicial</a></li>
        <li><a href="presenca.php">Formulário de Presença</a></li>
        <li><a href="perfil.php">Perfil</a></li>
        <li><a href="#">_____</a></li>
    </ul>
</div>


<p>
	INFORMAÇÕES PESSOAIS<br>
Nome:<?php echo "$linha[1]"; ?> <br>
Turma: <?php echo "$linha[5]"; ?> <br>
Matricula: <?php echo "$linha[2]"; ?> <br>
Idade: <?php echo "$linha[3]"; ?> <br>
Sexo: <?php echo "$linha[4]"; ?> <br>
Modalidade Individual: <?php echo "$linha[6]"; ?> <br>
Modalidade Coletiva: <?php echo "$linha[7]"; ?> <br>
</p>
CARACTERÍSTICAS FÍSICAS <br>
Altura:<?php echo "$linha[8]"; ?> <br>
Peso:<?php echo "$linha[9]"; ?> <br>
IMC:<?php $altura= $linha[8]/100; $IMC= $linha[9]/($altura*$altura); echo "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa $IMC"; ?> <br>

<a href='presencaaluno.php?aluno=<?php echo $linha[0];?>'>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa Ver meu histórico de frequência </a><br>
<a href='editar.php?aluno1=<?php echo $linha[0];?>'>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEditar Perfil</a>
OBSERVAÇÃO DO PROFESSOR
<?php //Maracutaia pra colocar o comentário ?>

</body>
</html>